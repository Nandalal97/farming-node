// Sample placeholder for a model
// Replace with MongoDB, MySQL, Sequelize, etc.
module.exports = {
    sampleData: () => {
      return [{ name: 'Aniket' }, { name: 'John' }];
    }
  };
  